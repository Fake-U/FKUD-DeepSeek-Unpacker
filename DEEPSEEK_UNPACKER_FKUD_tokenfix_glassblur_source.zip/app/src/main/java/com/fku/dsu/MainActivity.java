package com.fku.dsu;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.view.WindowInsets;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
import android.util.AtomicFile;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private int systemInsetTop = 0;
    private int systemInsetBottom = 0;
    private boolean pageLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 先启用透明系统栏；页面加载后由 HTML 当前主题同步系统图标明暗。
        applySystemBars("#F0EDE4", true);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        setContentView(webView);
        webView.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                systemInsetTop = bars.top;
                systemInsetBottom = bars.bottom;
            } else {
                systemInsetTop = insets.getSystemWindowInsetTop();
                systemInsetBottom = insets.getSystemWindowInsetBottom();
            }
            if (pageLoaded) applyWebInsets();
            return insets;
        });
        webView.requestApplyInsets();
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setDefaultTextEncodingName("UTF-8");
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new DownloadBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"file".equalsIgnoreCase(uri.getScheme());
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                applyWebInsets();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/zip", "application/json", "text/plain", "text/markdown",
                    "text/html", "text/csv", "application/vnd.ms-excel", "application/octet-stream"
                });
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); Toast.makeText(MainActivity.this, "无法打开文件选择器", Toast.LENGTH_SHORT).show(); }
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "DeepSeek_Unpacker_Export");
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
            } catch (Exception e) { Toast.makeText(this, "下载失败：" + e.getMessage(), Toast.LENGTH_LONG).show(); }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getData() != null) results = new Uri[]{data.getData()};
                else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) results = new Uri[]{data.getClipData().getItemAt(0).getUri()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    /** Edge-to-edge：系统栏透明，页面自身按系统 Insets 留出安全区域。 */
    private void applySystemBars(String hexColor, boolean darkIcons) {
        runOnUiThread(() -> {
            Window window = getWindow();
            window.setStatusBarColor(Color.TRANSPARENT);
            // Android 8.0 起支持深色导航栏图标；更早版本只能使用白色图标，因此降级为深色导航栏底色。
            window.setNavigationBarColor(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? Color.TRANSPARENT : Color.BLACK);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setNavigationBarContrastEnforced(false);
                window.setStatusBarContrastEnforced(false);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.setNavigationBarDividerColor(Color.TRANSPARENT);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
            }
            int flags = window.getDecorView().getSystemUiVisibility();
            flags |= View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (darkIcons) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (darkIcons) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
            if (pageLoaded) applyWebInsets();
        });
    }

    private void applyWebInsets() {
        if (webView == null || !pageLoaded) return;
        String js = "document.documentElement.style.setProperty('--android-inset-top','" + systemInsetTop
                + "px');document.documentElement.style.setProperty('--android-inset-bottom','" + systemInsetBottom + "px');";
        webView.evaluateJavascript(js, null);
    }

    private class DownloadBridge {
        @android.webkit.JavascriptInterface
        public void setSystemBars(String hexColor, boolean darkIcons) {
            applySystemBars(hexColor, darkIcons);
        }

        /** 对话与设置均保存在应用私有目录，不依赖 WebView 的临时页面状态。 */
        private boolean writePrivateFile(String name, String content) {
            if (content == null) return false;
            AtomicFile atomic = new AtomicFile(new java.io.File(getFilesDir(), name));
            java.io.FileOutputStream out = null;
            try {
                out = atomic.startWrite();
                out.write(content.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
                atomic.finishWrite(out);
                return true;
            } catch (Exception e) {
                if (out != null) atomic.failWrite(out);
                android.util.Log.e("DeepSeekUnpacker", "write private file failed: " + name, e);
                return false;
            }
        }

        private String readPrivateFile(String name) {
            AtomicFile atomic = new AtomicFile(new java.io.File(getFilesDir(), name));
            try (InputStream in = atomic.openRead(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                return out.toString("UTF-8");
            } catch (Exception e) {
                return "";
            }
        }

        @android.webkit.JavascriptInterface
        public boolean saveAppState(String json) { return writePrivateFile("dsu_state.json", json); }

        @android.webkit.JavascriptInterface
        public String loadAppState() { return readPrivateFile("dsu_state.json"); }

        @android.webkit.JavascriptInterface
        public boolean savePreferences(String json) { return writePrivateFile("dsu_preferences.json", json); }

        @android.webkit.JavascriptInterface
        public String loadPreferences() { return readPrivateFile("dsu_preferences.json"); }

        @android.webkit.JavascriptInterface
        public void saveBlob(String dataUrl, String fileName, String mimeType) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("导出数据格式无效");
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                String safeName = fileName == null ? "export.bin" : fileName.replaceAll("[^a-zA-Z0-9._\u4e00-\u9fa5-]", "_");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DeepSeek Unpacker");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("无法创建下载文件");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new IllegalStateException("无法写入文件"); out.write(bytes); }
                } else {
                    java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) throw new IllegalStateException("无法访问应用下载目录");
                    java.io.File outFile = new java.io.File(dir, safeName);
                    try (OutputStream out = new java.io.FileOutputStream(outFile)) { out.write(bytes); }
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "导出完成：" + safeName, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        if (webView != null) { webView.loadUrl("about:blank"); webView.destroy(); }
        super.onDestroy();
    }
}
