# DEEPSEEK UNPACKER Android

Android WebView wrapper project. The HTML application is bundled at `app/src/main/assets/index.html`.

## Build

The GitHub Actions workflow extracts the source ZIP uploaded to the repository root, then builds `:app:assembleDebug` and publishes the debug APK as an Actions artifact.

## Native system bar theme synchronization

The WebView HTML sends its active theme background color to `MainActivity` through `AndroidBridge.setSystemBars`. Android updates the status bar and navigation bar colors and chooses dark or light system icons based on the background luminance. For the glass theme, Android system bars use the configured solid background base because native system bars cannot reproduce the WebView's blur and translucent gradient effects.
