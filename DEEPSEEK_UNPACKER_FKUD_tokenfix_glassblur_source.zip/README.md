# DEEPSEEK UNPACKER Android

Android WebView wrapper project. The complete web application is bundled at `app/src/main/assets/index.html`.

## Build

Upload `DEEPSEEK_UNPACKER_FKUD_performance_optimized.zip` to the repository root. The included GitHub Actions workflow extracts it and builds `:app:assembleDebug`; the APK is published as the `DEEPSEEK-UNPACKER-debug-apk` artifact.

## Import formats

The unified file picker accepts JSON, ds chat-demo ZIP archives, TXT, Markdown (MD), HTML, and CSV. ZIP import recognizes legacy `conversations.json`, ds chat-demo `chat_sessions/*.json`, and text-format files stored inside a ZIP.

## Local persistence

On Android, conversations are saved as an atomic file in the app's private internal storage through `AndroidBridge`; preferences are stored separately. IndexedDB and localStorage are browser fallbacks. Imported conversations and selection state are persisted, then restored at startup.

## Android system bars

The app uses transparent edge-to-edge status and navigation bars. The WebView receives the current system insets and reserves safe space for the top toolbar, conversation area, and floating controls. System-bar icon contrast follows the active theme background luminance.

## THINK / RESPONSE handling

The edit-and-export text area hides THINK by default. The separate “保留原始 THINK” option is enabled by default and restores the original THINK data when exporting TXT, MD, JSON, or ZIP. Turning it off explicitly excludes THINK.
